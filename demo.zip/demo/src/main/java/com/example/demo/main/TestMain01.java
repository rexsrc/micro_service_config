package com.example.demo.main;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.example.demo.model.TestModel01;

public class TestMain01 {
	
	private static Logger LOG = LoggerFactory.getLogger(TestMain01.class);

	public static void main(String[] args) {
		
		String str = "String Object";
		LOG.debug("do someting: {} is String OK ",str);
		
		int i = 99;
		LOG.debug("do someting: {} is int OK ",i);
		
		String value1 = "Value 001";
		String value2 = "Value 002";
		LOG.debug("do someting: {} ,then do something: {} are String OK ",value1,value2);
		
		LOG.debug("do someting: {1} ,then do something: {2} is String OK ",value1,value2);
		
		String value3 = "Value 003";
		
		LOG.debug("do someting: {} ,then do something: {} ,then do something: {} are String OK ",value1,value2,value3);
		
		LOG.debug("do someting: {} ,then do something: {} are String OK ",value1,value2,value3);
		
		TestModel01 model = new TestModel01("normal", "confidential", "0980909090", 43443.44);
		LOG.debug("do someting: {} is model OK ",model);
	}

}
