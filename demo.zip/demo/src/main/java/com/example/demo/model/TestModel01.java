package com.example.demo.model;

import java.text.DecimalFormat;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TestModel01 {

	private String normalStr;
	private String confidentStr;
	private String mobileNo;
	private double salary;
	
	public TestModel01(String normalStr, String confidentStr, String mobileNo, double salary) {
		super();
		this.normalStr = normalStr;
		this.confidentStr = confidentStr;
		this.mobileNo = mobileNo;
		this.salary = salary;
	}
	
	
	public String getNormalStr() {
		return normalStr;
	}
	public void setNormalStr(String normalStr) {
		this.normalStr = normalStr;
	}
	public String getConfidentStr() {
		return confidentStr;
	}
	public void setConfidentStr(String confidentStr) {
		this.confidentStr = confidentStr;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	public String toJsonString() {
		try {
			return new ObjectMapper().writeValueAsString(this);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		} 
		return null;
	}
	
}
